package com.java.product.service;

import java.util.ArrayList;

import model.ProductImageVO;
import model.ProductSizeVO;
import model.ProductVO;

public interface Service {

	ArrayList<ProductDto> getProductAll();
	
	ArrayList<ProductSizeVO> getProductsSizeAll(int p_num);
	
	ArrayList<ProductDto> getProductManagementByPageNum(int page);
	
	ArrayList<ProductDto> getBestProducts(int numberItems);
	
	ArrayList<ProductDto> getNewProducts(int numberItems);
	
	ArrayList<ProductDto> getCategoryProducts(String category);
	
	ArrayList<ProductDto> getCategoryProductsByPageNum(String category, int page);
	
	ArrayList<ProductDto> getCategoryProductsSort(String category, int page, String orderBy);
	
	ArrayList<ProductDto> getKeywordProductsByPageNum(String keyword, int page);
	
	ArrayList<ProductDto> getKeywordProductsSort(String keyword, int page, String orderBy);
	
	ArrayList<ProductImageVO> getDetailImgAll(int p_num);
	
	ProductDto getProduct(int num);
	
	int checkQuantity(int productNum, String size);
	
	int makeProductNum();
	
	int makeProductImgNum();
	
	int makeProductSizeNum();
	
	void add(ProductDto p);
	
	void add(ProductImageVO pi);
	
	void add(ProductSizeVO ps);
	
	void addQuantity(ProductSizeVO ps);
	
	void delProduct(int num);
	
	void recordup(ProductDto productvo);
}
