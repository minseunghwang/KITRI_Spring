package com.java.admin.memberManage.service;

import model.MemberVO;

public interface Service {
	
	void editMember(MemberDto m); 
	void remMember(String id);

}
