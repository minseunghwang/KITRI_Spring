package com.java.admin.memberManage.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MemberManageController extends HttpServlet {
	@Autowired
	private static final long serialVersionUID = 1L;

	@RequestMapping(value="/")
	public String Main(HttpServletRequest request, HttpServletResponse response) {
		
//		Service service = new ServiceImpl();
//		ArrayList<MemberDto> members = service.getMemberAll();
		
//		HttpSession session = request.getSession();
//		System.out.println("session.getAttribute(type)" +session.getAttribute("memberType"));

		
//		boolean adminFlag = false;
//		int typeNum = 4;
//		if ( session.getAttribute("memberType") != null) {
//			adminFlag = true;
//			typeNum = (int) session.getAttribute("memberType");
//			System.out.println("typeNum:" + typeNum);
//			
//		} else {
//			adminFlag = false;
//			
//		}
//		
//		
//		if (typeNum == 0) {
//			request.setAttribute("members", members);
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/views/admin/member/memberManage.jsp");
//			dispatcher.forward(request, response);
//		} else {
//			PrintWriter writer = response.getWriter();
//			writer.println("<script>alert('관리자 계정으로 로그인이 필요합니다.'); location.href='views/member/login.jsp'; </script>");
//			writer.close();
//		}
		
		return "main/main";
	}
}
