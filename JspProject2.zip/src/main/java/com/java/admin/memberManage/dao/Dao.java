package com.java.admin.memberManage.dao;

import java.util.ArrayList;

import model.MemberVO;

public interface Dao {
	
	void update(MemberDto m);
	void delete(String id);

}
