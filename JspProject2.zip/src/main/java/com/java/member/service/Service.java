package com.java.member.service;

import java.util.ArrayList;

import model.MemberVO;
import model.ReviewVO;

public interface Service {
	void join(MemberDto m); 
	MemberDto getMember(String id); 
	void editMember(MemberDto m); 
	void remMember(String id);	
	boolean login(String id, String pwd);
	
	ArrayList<MemberDto> getMemberAll();
	ArrayList<MemberDto> getMemberByReviewId(ArrayList<ReviewDto> r);
	
	MemberDto searchId(String email);
	void editPwd(String email, String id); 
	int userIdCheck(String id);
}
