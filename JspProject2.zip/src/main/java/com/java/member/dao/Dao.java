package com.java.member.dao;

import java.util.ArrayList;

import model.MemberVO;
import model.ReviewVO;

public interface Dao {

	void insert(MemberDto m);
	MemberDto select(String id);
	void update(MemberDto m);
	void delete(String id);
	
	ArrayList<MemberDto> selectAllMember();
	ArrayList<MemberDto> selectMemberByReviewId(ArrayList<ReviewDto> r);
	
	MemberDto selectId(String email);
	void updatePwd(String email, String id);
	int checkOverId(String id);
}
