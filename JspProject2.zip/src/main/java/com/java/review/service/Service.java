package com.java.review.service;

import java.util.ArrayList;

import model.ReviewVO;



public interface Service {
	void add(ReviewDto notice);

	ReviewDto getReview(int num);
	
	ArrayList<ReviewDto> getReviewByProductNum(int p_num);
	ArrayList<ReviewDto> getReviewInProductByPageNum(int p_num, int page);

	void editReview(ReviewDto notice);

	void delReview(int num);

	ArrayList<ReviewDto> getReviewAll();

	int makeNum();
	int getSelectedP_num(int r_num);
	ArrayList<ReviewDto> getMyReviewAll(String m_id, int page);
	int getcountMine(String m_id);
	int getcountByP_Num(int p_num);
}
