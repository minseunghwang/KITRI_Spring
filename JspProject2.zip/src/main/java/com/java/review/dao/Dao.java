package com.java.review.dao;

import java.util.ArrayList;

import model.ReviewVO;



public interface Dao {
	int selectNum();
	int selectP_Num(int r_num);
	void insert(ReviewDto review);

	ReviewDto select(int num);
	
	ArrayList<ReviewDto> selectByP_Num(int p_num);
	ArrayList<ReviewDto> selectReviewInProductByPageNum(int p_num, int page);

	void update(ReviewDto notice);

	void delete(int num);

	ArrayList<ReviewDto> selectAll();

	ArrayList<ReviewDto> myselectAll(String m_id, int page);
	int countallmine(String m_id);
	int countreviewByP_Num(int p_num);
}
