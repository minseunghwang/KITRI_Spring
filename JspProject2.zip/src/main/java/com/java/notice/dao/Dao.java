package com.java.notice.dao;

import java.util.ArrayList;

import model.NoticeVO;
import model.ProductVO;

public interface Dao {
	int selectNum();

	void insert(NoticeDto notice);

	NoticeDto select(int num);

	void update(NoticeDto notice);

	void delete(int num);

	ArrayList<NoticeDto> selectAll();
	
	void updateViewCount(NoticeDto notice);

	int countallmine();

	ArrayList<NoticeDto> selectNoticeByPageNum(int page);
	ArrayList<NoticeDto> selectNoticeheader();
}
