package com.java.notice.service;

import java.util.ArrayList;

import model.NoticeVO;
import model.ProductVO;

public interface Service {
	void add(NoticeDto notice);

	NoticeDto  getNotice(int num);

	void editNotice(NoticeDto notice);

	void delNotice(int num);

	ArrayList<NoticeDto> getNoticeAll();

	// int makeNum();

	void updateViewCount(NoticeDto notice);

	int getcountMine();
	ArrayList<NoticeDto> getNoticeByPageNum(int page);
	ArrayList<NoticeDto> getNoticeheader();

}
