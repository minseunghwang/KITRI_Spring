package com.java.productOrder.dao;

import java.util.ArrayList;

import model.OrderInfoVO;
import model.ProductOrderVO;
import model.ProductVO;


public interface Dao {
	void insert(ProductOrderDto po);
	ProductOrderDto select(int num);
	ArrayList<ProductOrderDto> selectAll(String m_id, int o_state);	//주문한 모든 상품 by 상품별
	ArrayList<ProductOrderDto> selectAllByCNum(String m_id, String code_num); //주문 번호 별 주문 상품
	ArrayList<ProductOrderDto> selectAllsimpleorderlist(String m_id, int o_state, int page); //주문한 모든 상품 list 
	int countAllByCNum(String m_id, int o_state); //페이징 위한 totalcount 
	void delete(int num);
	void update(String type, int num);
	
	int selectProductOrderNum();
	int selectProductOrderCodeNum();
	
	void updateR_State(String m_id, int o_num);
	
	ArrayList<ProductOrderDto> selectRecentOrder(String m_id);
	
	void updatePoint(String m_id, int o_num);
	
	int selectProductInCartNum(String m_id, int p_num, String size);
	int selectProductQuantity(int p_num, String psize);
	
	int selectCartListCountById(String m_id);
	
	
	int selectOrderInfoNum();
	
	
	void insert(OrderInfoVO oivo);
	void updateCode_num(ProductOrderDto po);
	
	OrderInfoVO selectOrderInfo(String code_num);
}
